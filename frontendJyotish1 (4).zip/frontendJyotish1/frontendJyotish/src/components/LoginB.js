// LoginButton.js

import React from 'react';
import Button from './Button';

const LoginButton = ({ onLoginClick, isLoggedIn }) => {
    return (
        <></>
    );
};

export default LoginButton;
